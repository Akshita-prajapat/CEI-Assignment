import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.memory.memory_store import MemoryStore
from src.memory.user_memory import UserMemoryManager


def _fresh_store() -> MemoryStore:
    tmp_dir = tempfile.mkdtemp()
    return MemoryStore(db_path=str(Path(tmp_dir) / "test_memory.sqlite3"))


def test_set_and_get_preference():
    store = _fresh_store()
    store.set_preference("u1", "name", "Alice")
    prefs = store.get_preferences("u1")
    assert prefs["name"] == "Alice"


def test_conversation_history_order():
    store = _fresh_store()
    store.add_message("u1", "user", "hello")
    store.add_message("u1", "assistant", "hi there")
    history = store.get_recent_history("u1", limit=5)
    assert history[0]["role"] == "user"
    assert history[1]["role"] == "assistant"


def test_fact_pruning():
    store = _fresh_store()
    store.MAX_MEMORY_ITEMS if hasattr(store, "MAX_MEMORY_ITEMS") else None
    for i in range(60):
        store.add_fact("u1", f"fact {i}")
    facts = store.get_facts("u1")
    assert len(facts) <= 60  # bounded by settings.MAX_MEMORY_ITEMS


def test_user_memory_manager_extracts_name():
    store = _fresh_store()
    manager = UserMemoryManager()
    manager.store = store  # inject fresh store
    manager.process_turn("u1", "Hi, my name is Bob", "Nice to meet you Bob!")
    prefs = store.get_preferences("u1")
    assert prefs.get("name") == "Bob"


if __name__ == "__main__":
    test_set_and_get_preference()
    test_conversation_history_order()
    test_fact_pruning()
    test_user_memory_manager_extracts_name()
    print("All memory tests passed.")
