import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.knowledge_graph.graph_builder import NetworkXGraphBackend
from src.knowledge_graph.entity_extraction import EntityExtractor


def test_add_and_query_triple():
    tmp_dir = tempfile.mkdtemp()
    backend = NetworkXGraphBackend(path=str(Path(tmp_dir) / "graph.gpickle"))
    backend.add_triple("RAG", "combines", "retrieval and generation")
    results = backend.query_neighbors("RAG")
    assert len(results) == 1
    assert results[0]["object"] == "retrieval and generation"


def test_save_and_load_graph():
    tmp_dir = tempfile.mkdtemp()
    path = str(Path(tmp_dir) / "graph.gpickle")
    backend = NetworkXGraphBackend(path=path)
    backend.add_triple("A", "relates_to", "B")
    backend.save()

    reloaded = NetworkXGraphBackend(path=path)
    reloaded.load()
    results = reloaded.query_neighbors("A")
    assert len(results) == 1


def test_heuristic_entity_extraction_fallback():
    extractor = EntityExtractor()
    extractor._use_spacy = False  # force fallback path
    entities = extractor.extract_entities("Anthropic built Claude in San Francisco.")
    texts = [e["text"] for e in entities]
    assert "Anthropic" in texts or "Claude" in texts


if __name__ == "__main__":
    test_add_and_query_triple()
    test_save_and_load_graph()
    test_heuristic_entity_extraction_fallback()
    print("All knowledge graph tests passed.")
