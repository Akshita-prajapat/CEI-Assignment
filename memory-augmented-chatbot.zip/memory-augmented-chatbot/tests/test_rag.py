import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.rag.chunking import chunk_text
from src.scraping.cleaner import clean_text, deduplicate_documents


def test_chunk_text_basic():
    text = " ".join(["word"] * 1000)
    chunks = chunk_text(text, chunk_size=100, overlap=10)
    assert len(chunks) > 1
    for c in chunks:
        assert len(c.split()) <= 100


def test_chunk_text_empty():
    assert chunk_text("") == []


def test_clean_text_removes_boilerplate():
    text = "Real content here.\nAll rights reserved.\nMore real content."
    cleaned = clean_text(text)
    assert "all rights reserved" not in cleaned.lower()
    assert "Real content here." in cleaned


def test_deduplicate_documents():
    docs = [
        {"url": "a", "text": "same content here"},
        {"url": "b", "text": "same content here"},
        {"url": "c", "text": "different content entirely"},
    ]
    unique = deduplicate_documents(docs)
    assert len(unique) == 2


if __name__ == "__main__":
    test_chunk_text_basic()
    test_chunk_text_empty()
    test_clean_text_removes_boilerplate()
    test_deduplicate_documents()
    print("All RAG tests passed.")
