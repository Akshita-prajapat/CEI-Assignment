# Memory-Augmented Chatbot

A context-aware, personalized chatbot that combines three complementary
knowledge sources through a single [LangGraph](https://github.com/langchain-ai/langgraph)
orchestration layer:

1. **RAG (Retrieval-Augmented Generation)** — a hybrid pipeline that scrapes,
   cleans, chunks, embeds, and indexes web content into a FAISS vector store
   for static knowledge retrieval.
2. **Knowledge Graph** — entities and relationships extracted from the same
   content, stored as a graph (NetworkX by default, Neo4j-ready) for
   relational/structured queries.
3. **Long-term Memory** — a SQLite-backed store that remembers user
   preferences, facts, and conversation history across sessions.

LangGraph also wires in **dynamic tools** (live weather, calculator, web
search hook) so the bot can fetch real-time information when static
knowledge and memory aren't enough. An **evaluation framework** scores every
response on retrieval relevance, faithfulness, correctness, and more.

```
                 ┌─────────────┐
   query ───────▶│ memory_node │  always loads user's long-term memory
                 └──────┬──────┘
                        ▼
                 ┌─────────────┐
                 │ router_node │  real-time tool needed? or static knowledge?
                 └──────┬──────┘
              ┌─────────┴─────────┐
              ▼                   ▼
        ┌──────────┐        ┌──────────┐
        │ tool_node│        │ rag_node │──▶┌──────────┐
        └────┬─────┘        └──────────┘   │graph_node│
             │                              └────┬─────┘
             └─────────────┬───────────────────--┘
                            ▼
                     generation_node (LLM)
                            │
                            ▼
                        final_answer
```

## Features

- 🕸️ **Web scraping + cleaning pipeline** (`requests` + `BeautifulSoup`) with
  boilerplate stripping and deduplication
- 📚 **RAG**: sentence-transformer embeddings + FAISS similarity search
- 🔗 **Knowledge graph**: spaCy-based entity/relation extraction (with a
  dependency-free heuristic fallback so it always runs) into NetworkX or Neo4j
- 🧠 **Long-term memory**: SQLite store for preferences, facts, and chat
  history, automatically updated from conversation
- 🛠️ **LangGraph tool orchestration**: real-time weather, calculator, and a
  pluggable web-search hook, routed dynamically per query
- 🤖 **Pluggable LLM backend**: Anthropic Claude or OpenAI, swappable via one
  config value — plus a no-key "stub" mode so the whole pipeline is testable
  without an API key
- 📊 **Evaluation framework**: embedding-similarity metrics (no LLM needed)
  plus optional LLM-judge metrics (faithfulness, correctness)
- 🌐 **FastAPI REST API** + Dockerfile + docker-compose for deployment
- ✅ **Unit tests** for RAG, memory, and knowledge-graph modules

## Project structure

```
memory-augmented-chatbot/
├── src/
│   ├── config.py                  # central settings (env-driven)
│   ├── scraping/
│   │   ├── scraper.py             # requests + BeautifulSoup scraper
│   │   └── cleaner.py             # text cleaning & deduplication
│   ├── rag/
│   │   ├── chunking.py            # overlapping chunk splitter
│   │   ├── embeddings.py          # sentence-transformers wrapper
│   │   ├── vector_store.py        # FAISS index (build/save/load/search)
│   │   └── retriever.py           # formats retrieved chunks into context
│   ├── knowledge_graph/
│   │   ├── entity_extraction.py   # spaCy NER/relations + heuristic fallback
│   │   ├── graph_builder.py       # NetworkX / Neo4j backends
│   │   └── graph_query.py         # neighbor/relation lookups for a query
│   ├── memory/
│   │   ├── memory_store.py        # SQLite: preferences, facts, history
│   │   └── user_memory.py         # decides what to remember per turn
│   ├── llm/
│   │   └── llm_client.py          # Anthropic / OpenAI / stub client
│   ├── langgraph_workflow/
│   │   ├── state.py               # shared ChatState schema
│   │   ├── tools.py                # weather / calculator / web-search tools
│   │   ├── nodes.py               # router, memory, rag, graph, tool, generate
│   │   └── graph.py               # StateGraph wiring + run_chat()
│   ├── evaluation/
│   │   ├── metrics.py             # relevance, similarity, faithfulness, etc.
│   │   └── evaluator.py           # runs a QA dataset end-to-end, reports scores
│   └── api/
│       ├── main.py                # FastAPI app (chat, memory, ingest, evaluate)
│       └── schemas.py             # request/response models
├── scripts/
│   ├── run_scraper.py             # scrape URLs standalone
│   ├── build_knowledge_base.py    # full pipeline: scrape→clean→chunk→index→graph
│   ├── evaluate.py                # run the evaluation suite
│   └── chat_cli.py                # interactive terminal chat client
├── tests/
│   ├── test_rag.py
│   ├── test_memory.py
│   └── test_graph.py
├── data/
│   ├── sample_urls.txt            # seed URLs for the knowledge base
│   └── sample_eval_dataset.json   # example QA set for evaluation
├── requirements.txt
├── .env.example
├── Dockerfile
├── docker-compose.yml
└── README.md
```

## Quickstart

### 1. Install dependencies

```bash
python -m venv venv
source venv/bin/activate       # Windows: venv\Scripts\activate
pip install -r requirements.txt

# Optional: only needed for full spaCy-based entity extraction
# (the pipeline works fine without this via a heuristic fallback)
python -m spacy download en_core_web_sm
```

### 2. Configure environment

```bash
cp .env.example .env
# Edit .env and add your ANTHROPIC_API_KEY (or OPENAI_API_KEY + LLM_PROVIDER=openai)
```

> No API key yet? Set `LLM_PROVIDER=none` and the pipeline still runs end to
> end with stub responses — useful for testing retrieval/memory/graph logic
> without paying for LLM calls.

### 3. Build the static knowledge base

```bash
python scripts/build_knowledge_base.py --urls-file data/sample_urls.txt
```

This scrapes the seed URLs, cleans and chunks the text, embeds and indexes it
into FAISS, and extracts a knowledge graph — all saved under `data/`.

### 4. Chat with it

**Terminal:**
```bash
python scripts/chat_cli.py --user-id alice
```

**API:**
```bash
uvicorn src.api.main:app --reload
# then, in another terminal:
curl -X POST http://localhost:8000/chat \
  -H "Content-Type: application/json" \
  -d '{"user_id": "alice", "message": "What is retrieval-augmented generation?"}'
```

Interactive docs are available at `http://localhost:8000/docs`.

### 5. Run the evaluation suite

```bash
python scripts/evaluate.py
```

Produces an aggregate report (`data/evaluation_report.json`) scoring context
relevance, answer similarity, keyword coverage, response length, latency, and
(if an LLM key is configured) LLM-judged faithfulness and correctness.

### 6. Run tests

```bash
pytest tests/ -v
```

## Using Docker

```bash
docker-compose up --build
```

This starts the FastAPI app on port 8000. Neo4j is included in
`docker-compose.yml` but only required if you set `GRAPH_BACKEND=neo4j` in
`.env` — the default `networkx` backend needs no external service at all.

## How personalization works

Every message updates `MemoryStore`: the raw turn is logged to conversation
history, and simple pattern matching (name, location, likes/dislikes, etc.)
promotes durable facts into long-term memory. On the next turn, `memory_node`
loads that context and feeds it to the LLM alongside RAG/graph context, so
the bot's answers reflect what it has learned about the user over time. For
smarter fact extraction, wire an LLM into
`UserMemoryManager.extract_facts_with_llm()`.

## Extending the project

- **Swap the graph backend**: set `GRAPH_BACKEND=neo4j` in `.env` and point
  `NEO4J_URI`/`NEO4J_USER`/`NEO4J_PASSWORD` at your instance — no code changes
  needed elsewhere.
- **Add a real web-search tool**: replace `web_search_stub` in
  `src/langgraph_workflow/tools.py` with a call to Tavily/SerpAPI/Bing.
- **Swap the LLM**: change `LLM_PROVIDER` to `openai` and set
  `OPENAI_API_KEY`/`OPENAI_MODEL`.
- **Bigger crawls**: `WebScraper` is intentionally simple; swap in Scrapy or
  add async/concurrent fetching for larger corpora.

## License

MIT — see [LICENSE](LICENSE).
