"""
Runs the evaluation suite against data/sample_eval_dataset.json (or a
custom dataset) and prints/saves a report.

Usage:
    python scripts/evaluate.py --dataset data/sample_eval_dataset.json
"""
import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.evaluation.evaluator import Evaluator, print_summary
from src.config import BASE_DIR


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset", type=str, default=str(BASE_DIR / "data" / "sample_eval_dataset.json"))
    parser.add_argument("--no-llm-judge", action="store_true", help="Skip LLM-based judge metrics")
    args = parser.parse_args()

    evaluator = Evaluator(use_llm_judge=not args.no_llm_judge)
    report = evaluator.evaluate_dataset(Path(args.dataset))
    out_path = evaluator.save_report(report)

    print_summary(report)
    print(f"\nFull report saved to {out_path}")


if __name__ == "__main__":
    main()
