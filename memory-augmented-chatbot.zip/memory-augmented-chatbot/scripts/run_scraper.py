"""
Standalone script: scrape a list of URLs into data/raw/scraped_documents.json

Usage:
    python scripts/run_scraper.py --urls-file data/sample_urls.txt
    python scripts/run_scraper.py --urls "https://example.com" "https://example.org"
"""
import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.scraping.scraper import WebScraper


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--urls-file", type=str, help="Path to a text file with one URL per line")
    parser.add_argument("--urls", nargs="*", help="URLs passed directly on the command line")
    args = parser.parse_args()

    urls = list(args.urls or [])
    if args.urls_file:
        with open(args.urls_file, "r", encoding="utf-8") as f:
            urls += [line.strip() for line in f if line.strip() and not line.startswith("#")]

    if not urls:
        print("No URLs provided. Use --urls-file or --urls.")
        return

    scraper = WebScraper()
    docs = scraper.scrape_urls(urls)
    out_path = scraper.save_documents(docs)
    print(f"Scraped {len(docs)}/{len(urls)} URLs successfully -> {out_path}")


if __name__ == "__main__":
    main()
