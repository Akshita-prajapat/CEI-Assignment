"""
End-to-end static knowledge base builder:
    scrape -> clean -> chunk -> embed & index (FAISS) -> knowledge graph

Usage:
    python scripts/build_knowledge_base.py --urls-file data/sample_urls.txt
"""
import argparse
import json
import logging
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

from src.scraping.scraper import WebScraper
from src.scraping.cleaner import clean_documents
from src.rag.chunking import chunk_documents
from src.rag.vector_store import get_vector_store
from src.knowledge_graph.graph_builder import KnowledgeGraphBuilder


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--urls-file", type=str, default="data/sample_urls.txt")
    args = parser.parse_args()

    with open(args.urls_file, "r", encoding="utf-8") as f:
        urls = [line.strip() for line in f if line.strip() and not line.startswith("#")]

    logger.info(f"Step 1/5: Scraping {len(urls)} URLs...")
    scraper = WebScraper()
    docs = scraper.scrape_urls(urls)
    raw_path = scraper.save_documents(docs)

    logger.info("Step 2/5: Cleaning documents...")
    cleaned_path = clean_documents(input_path=raw_path)

    logger.info("Step 3/5: Chunking documents...")
    chunks_path = chunk_documents(input_path=cleaned_path)

    with open(chunks_path, "r", encoding="utf-8") as f:
        chunks = json.load(f)

    logger.info(f"Step 4/5: Embedding & indexing {len(chunks)} chunks into FAISS...")
    vector_store = get_vector_store()
    vector_store.build(chunks)
    vector_store.save()

    logger.info("Step 5/5: Building knowledge graph...")
    kg_builder = KnowledgeGraphBuilder()
    num_triples = kg_builder.build_from_chunks(chunks_path)

    logger.info(
        f"Done. {len(docs)} docs scraped, {len(chunks)} chunks indexed, "
        f"{num_triples} graph triples extracted."
    )


if __name__ == "__main__":
    main()
