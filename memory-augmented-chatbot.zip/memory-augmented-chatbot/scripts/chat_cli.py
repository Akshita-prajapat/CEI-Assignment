"""
Simple interactive command-line chat client for local testing without
needing to run the FastAPI server.

Usage:
    python scripts/chat_cli.py --user-id alice
"""
import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.langgraph_workflow.graph import run_chat


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--user-id", type=str, default="local_user")
    args = parser.parse_args()

    print("Memory-Augmented Chatbot — type 'exit' to quit.\n")
    while True:
        try:
            message = input("You: ").strip()
        except (EOFError, KeyboardInterrupt):
            break
        if message.lower() in ("exit", "quit"):
            break
        if not message:
            continue

        result = run_chat(args.user_id, message)
        print(f"\nBot ({result.get('route')}): {result.get('final_answer')}\n")


if __name__ == "__main__":
    main()
