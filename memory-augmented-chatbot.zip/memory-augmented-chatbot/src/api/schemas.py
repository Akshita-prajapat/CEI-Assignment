from typing import List, Dict, Optional
from pydantic import BaseModel


class ChatRequest(BaseModel):
    user_id: str
    message: str


class ChatResponse(BaseModel):
    answer: str
    sources: List[Dict] = []
    route: Optional[str] = None


class PreferenceRequest(BaseModel):
    user_id: str
    key: str
    value: str


class IngestRequest(BaseModel):
    urls: List[str]


class MemoryResponse(BaseModel):
    preferences: Dict[str, str]
    facts: List[str]
    recent_history: List[Dict]
