"""
FastAPI application exposing the memory-augmented chatbot as a REST API.

Run with:
    uvicorn src.api.main:app --reload --host 0.0.0.0 --port 8000

Endpoints:
    POST /chat                 -> send a message, get a response
    GET  /memory/{user_id}     -> inspect a user's long-term memory
    POST /memory/preference    -> manually set a user preference
    POST /ingest                -> scrape + clean + chunk + index new URLs
    POST /evaluate               -> run the evaluation suite, return report
    GET  /health                 -> liveness check
"""
import logging
from pathlib import Path

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware

from src.api.schemas import (
    ChatRequest,
    ChatResponse,
    PreferenceRequest,
    IngestRequest,
    MemoryResponse,
)
from src.langgraph_workflow.graph import run_chat
from src.memory.memory_store import get_memory_store
from src.scraping.scraper import WebScraper
from src.scraping.cleaner import clean_documents
from src.rag.chunking import chunk_documents
from src.rag.vector_store import get_vector_store
from src.knowledge_graph.graph_builder import KnowledgeGraphBuilder
from src.evaluation.evaluator import Evaluator
from src.config import BASE_DIR

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(
    title="Memory-Augmented Chatbot API",
    description="RAG + Knowledge Graph + Long-term Memory + LangGraph tool orchestration",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/chat", response_model=ChatResponse)
def chat(req: ChatRequest):
    try:
        result = run_chat(req.user_id, req.message)
    except Exception as exc:
        logger.exception("Chat pipeline failed")
        raise HTTPException(status_code=500, detail=str(exc))

    return ChatResponse(
        answer=result.get("final_answer", ""),
        sources=result.get("rag_sources", []),
        route=result.get("route"),
    )


@app.get("/memory/{user_id}", response_model=MemoryResponse)
def get_memory(user_id: str):
    store = get_memory_store()
    return MemoryResponse(
        preferences=store.get_preferences(user_id),
        facts=store.get_facts(user_id),
        recent_history=store.get_recent_history(user_id),
    )


@app.post("/memory/preference")
def set_preference(req: PreferenceRequest):
    store = get_memory_store()
    store.set_preference(req.user_id, req.key, req.value)
    return {"status": "saved"}


@app.post("/ingest")
def ingest(req: IngestRequest):
    """
    Full static-knowledge pipeline: scrape -> clean -> chunk -> embed -> index -> graph.
    """
    try:
        scraper = WebScraper()
        docs = scraper.scrape_urls(req.urls)
        raw_path = scraper.save_documents(docs)

        cleaned_path = clean_documents(input_path=raw_path)
        chunks_path = chunk_documents(input_path=cleaned_path)

        import json
        with open(chunks_path, "r", encoding="utf-8") as f:
            chunks = json.load(f)

        vector_store = get_vector_store()
        vector_store.build(chunks)
        vector_store.save()

        kg_builder = KnowledgeGraphBuilder()
        num_triples = kg_builder.build_from_chunks(chunks_path)

        return {
            "status": "ok",
            "documents_scraped": len(docs),
            "chunks_indexed": len(chunks),
            "graph_triples_extracted": num_triples,
        }
    except Exception as exc:
        logger.exception("Ingestion failed")
        raise HTTPException(status_code=500, detail=str(exc))


@app.post("/evaluate")
def evaluate():
    dataset_path = BASE_DIR / "data" / "sample_eval_dataset.json"
    if not Path(dataset_path).exists():
        raise HTTPException(status_code=404, detail="No evaluation dataset found at data/sample_eval_dataset.json")
    evaluator = Evaluator()
    report = evaluator.evaluate_dataset(dataset_path)
    evaluator.save_report(report)
    return report
