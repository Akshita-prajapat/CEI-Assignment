"""
Entity & relationship extraction for building the knowledge graph.

Uses spaCy if a model is available for proper NER + noun-phrase
relations. Falls back to a lightweight regex/heuristic extractor
if spaCy or its model isn't installed, so the pipeline never hard-fails.
"""
import logging
import re
from typing import List, Tuple, Dict

logger = logging.getLogger(__name__)

Triple = Tuple[str, str, str]  # (subject, relation, object)


class EntityExtractor:
    def __init__(self, spacy_model: str = "en_core_web_sm"):
        self.spacy_model_name = spacy_model
        self._nlp = None
        self._use_spacy = True

    @property
    def nlp(self):
        if self._nlp is None and self._use_spacy:
            try:
                import spacy
                self._nlp = spacy.load(self.spacy_model_name)
            except Exception as exc:
                logger.warning(
                    f"spaCy model '{self.spacy_model_name}' unavailable ({exc}); "
                    "falling back to heuristic entity extraction."
                )
                self._use_spacy = False
        return self._nlp

    def extract_entities(self, text: str) -> List[Dict]:
        if self._use_spacy and self.nlp is not None:
            doc = self.nlp(text)
            return [{"text": ent.text, "label": ent.label_} for ent in doc.ents]
        return self._heuristic_entities(text)

    def extract_triples(self, text: str) -> List[Triple]:
        """
        Extract simple (subject, relation, object) triples.
        With spaCy: uses dependency parsing to find SVO patterns.
        Without spaCy: uses a naive sentence-pattern heuristic.
        """
        if self._use_spacy and self.nlp is not None:
            return self._spacy_triples(text)
        return self._heuristic_triples(text)

    # ---------- spaCy-based extraction ----------
    def _spacy_triples(self, text: str) -> List[Triple]:
        triples = []
        doc = self.nlp(text)
        for sent in doc.sents:
            subject, relation, obj = None, None, None
            for token in sent:
                if token.dep_ in ("nsubj", "nsubjpass"):
                    subject = token.text
                if token.pos_ == "VERB":
                    relation = token.lemma_
                if token.dep_ in ("dobj", "attr", "pobj"):
                    obj = token.text
            if subject and relation and obj:
                triples.append((subject, relation, obj))
        return triples

    # ---------- fallback heuristics (no external model needed) ----------
    def _heuristic_entities(self, text: str) -> List[Dict]:
        # Capture capitalized multi-word phrases as naive "entities"
        pattern = re.compile(r"\b([A-Z][a-zA-Z]+(?:\s+[A-Z][a-zA-Z]+)*)\b")
        found = set(pattern.findall(text))
        stopwords = {"The", "This", "That", "It", "A", "An"}
        return [{"text": e, "label": "MISC"} for e in found if e not in stopwords]

    def _heuristic_triples(self, text: str) -> List[Triple]:
        triples = []
        # naive "X is Y", "X uses Y", "X enables Y" pattern matching
        patterns = [
            r"([A-Z][\w\s]{1,40}?)\s+(is|are|uses|enables|includes|combines|integrates|requires)\s+([\w\s,]{1,60}?)[\.\n]",
        ]
        for pattern in patterns:
            for match in re.finditer(pattern, text):
                subj, rel, obj = match.group(1).strip(), match.group(2).strip(), match.group(3).strip()
                triples.append((subj, rel, obj))
        return triples
