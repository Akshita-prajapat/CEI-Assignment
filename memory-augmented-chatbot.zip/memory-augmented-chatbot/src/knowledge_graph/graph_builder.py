"""
Knowledge graph construction.

Two backends are supported:
  - "networkx" (default): a local, file-persisted graph. No external
    services needed — perfect for development, demos, and grading.
  - "neo4j": a production-grade graph database. Set GRAPH_BACKEND=neo4j
    and the NEO4J_* env vars in .env to use it.

Both backends implement the same minimal interface: add_triple() and
query_neighbors(), so the rest of the app is backend-agnostic.
"""
import json
import logging
import pickle
from pathlib import Path
from typing import List, Dict

import networkx as nx

from src.config import settings, PROCESSED_DATA_DIR
from src.knowledge_graph.entity_extraction import EntityExtractor, Triple

logger = logging.getLogger(__name__)


class NetworkXGraphBackend:
    def __init__(self, path: str = None):
        self.path = path or settings.GRAPH_STORE_PATH
        self.graph = nx.MultiDiGraph()

    def add_triple(self, subject: str, relation: str, obj: str, source: str = ""):
        self.graph.add_node(subject)
        self.graph.add_node(obj)
        self.graph.add_edge(subject, obj, relation=relation, source=source)

    def query_neighbors(self, entity: str, max_hops: int = 1) -> List[Dict]:
        if entity not in self.graph:
            # case-insensitive fallback
            matches = [n for n in self.graph.nodes if n.lower() == entity.lower()]
            if not matches:
                return []
            entity = matches[0]

        results = []
        visited = {entity}
        frontier = [entity]
        for _ in range(max_hops):
            next_frontier = []
            for node in frontier:
                for _, target, data in self.graph.out_edges(node, data=True):
                    results.append({"subject": node, "relation": data.get("relation"), "object": target})
                    if target not in visited:
                        visited.add(target)
                        next_frontier.append(target)
                for source, _, data in self.graph.in_edges(node, data=True):
                    results.append({"subject": source, "relation": data.get("relation"), "object": node})
                    if source not in visited:
                        visited.add(source)
                        next_frontier.append(source)
            frontier = next_frontier
        return results

    def save(self):
        Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        with open(self.path, "wb") as f:
            pickle.dump(self.graph, f)
        logger.info(f"Saved graph ({self.graph.number_of_nodes()} nodes, "
                    f"{self.graph.number_of_edges()} edges) -> {self.path}")

    def load(self):
        if Path(self.path).exists():
            with open(self.path, "rb") as f:
                self.graph = pickle.load(f)
            logger.info(f"Loaded graph with {self.graph.number_of_nodes()} nodes")
        else:
            logger.warning("No saved graph found; starting with an empty graph.")


class Neo4jGraphBackend:
    def __init__(self):
        from neo4j import GraphDatabase  # imported lazily; optional dependency
        self.driver = GraphDatabase.driver(
            settings.NEO4J_URI, auth=(settings.NEO4J_USER, settings.NEO4J_PASSWORD)
        )

    def add_triple(self, subject: str, relation: str, obj: str, source: str = ""):
        query = (
            "MERGE (s:Entity {name: $subject}) "
            "MERGE (o:Entity {name: $object}) "
            "MERGE (s)-[r:RELATION {type: $relation, source: $source}]->(o)"
        )
        with self.driver.session() as session:
            session.run(query, subject=subject, object=obj, relation=relation, source=source)

    def query_neighbors(self, entity: str, max_hops: int = 1) -> List[Dict]:
        query = (
            f"MATCH (e:Entity {{name: $entity}})-[r*1..{max_hops}]-(n) "
            "RETURN e.name AS subject, n.name AS object, r AS rel LIMIT 50"
        )
        with self.driver.session() as session:
            result = session.run(query, entity=entity)
            return [{"subject": rec["subject"], "object": rec["object"], "relation": "related_to"} for rec in result]

    def save(self):
        pass  # Neo4j persists automatically

    def load(self):
        pass


def get_graph_backend():
    if settings.GRAPH_BACKEND == "neo4j":
        return Neo4jGraphBackend()
    return NetworkXGraphBackend()


class KnowledgeGraphBuilder:
    def __init__(self):
        self.backend = get_graph_backend()
        self.extractor = EntityExtractor()

    def build_from_chunks(self, chunks_path: Path = None):
        chunks_path = chunks_path or (PROCESSED_DATA_DIR / "chunks.json")
        with open(chunks_path, "r", encoding="utf-8") as f:
            chunks = json.load(f)

        total_triples = 0
        for chunk in chunks:
            triples = self.extractor.extract_triples(chunk["text"])
            for subj, rel, obj in triples:
                self.backend.add_triple(subj, rel, obj, source=chunk.get("doc_url", ""))
                total_triples += 1

        logger.info(f"Extracted {total_triples} triples from {len(chunks)} chunks")
        self.backend.save()
        return total_triples


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    builder = KnowledgeGraphBuilder()
    builder.build_from_chunks()
