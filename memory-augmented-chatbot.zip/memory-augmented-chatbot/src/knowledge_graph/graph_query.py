"""
Query interface over the knowledge graph, used by the LangGraph
"graph_node" to answer structured/relational questions.
"""
import logging
import re
from typing import List, Dict

from src.knowledge_graph.graph_builder import get_graph_backend

logger = logging.getLogger(__name__)

_CAPITALIZED_RE = re.compile(r"\b([A-Z][a-zA-Z]+(?:\s+[A-Z][a-zA-Z]+)*)\b")


class GraphQueryEngine:
    def __init__(self):
        self.backend = get_graph_backend()
        self.backend.load()

    def extract_candidate_entities(self, query: str) -> List[str]:
        candidates = _CAPITALIZED_RE.findall(query)
        stopwords = {"The", "What", "Who", "How", "Why", "When", "Where"}
        return [c for c in candidates if c not in stopwords]

    def query(self, query: str, max_hops: int = 1) -> List[Dict]:
        entities = self.extract_candidate_entities(query)
        results = []
        for entity in entities:
            results.extend(self.backend.query_neighbors(entity, max_hops=max_hops))
        return results

    def format_as_context(self, results: List[Dict]) -> str:
        if not results:
            return ""
        lines = [f"{r['subject']} --{r['relation']}--> {r['object']}" for r in results]
        return "Knowledge graph facts:\n" + "\n".join(lines)
