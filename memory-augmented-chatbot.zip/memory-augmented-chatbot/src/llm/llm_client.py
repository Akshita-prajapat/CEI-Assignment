"""
Thin LLM client abstraction so the rest of the app doesn't care whether
Claude (Anthropic) or GPT (OpenAI) is used underneath. Controlled by
LLM_PROVIDER in .env. Defaults to Anthropic since this project is built
in the Claude ecosystem, but OpenAI is a drop-in alternative.
"""
import logging
from typing import List, Dict, Optional

from src.config import settings

logger = logging.getLogger(__name__)


class LLMClient:
    def __init__(self, provider: str = None):
        self.provider = provider or settings.LLM_PROVIDER
        self._client = None

    def _get_anthropic_client(self):
        if self._client is None:
            import anthropic
            self._client = anthropic.Anthropic(api_key=settings.ANTHROPIC_API_KEY)
        return self._client

    def _get_openai_client(self):
        if self._client is None:
            import openai
            self._client = openai.OpenAI(api_key=settings.OPENAI_API_KEY)
        return self._client

    def complete(self, prompt: str, system: Optional[str] = None, max_tokens: int = 1024) -> str:
        """Single-turn completion; used for quick extraction/eval tasks."""
        return self.chat([{"role": "user", "content": prompt}], system=system, max_tokens=max_tokens)

    def chat(self, messages: List[Dict], system: Optional[str] = None, max_tokens: int = 1024) -> str:
        if self.provider == "anthropic":
            return self._chat_anthropic(messages, system, max_tokens)
        elif self.provider == "openai":
            return self._chat_openai(messages, system, max_tokens)
        else:
            return self._echo_fallback(messages)

    def _chat_anthropic(self, messages, system, max_tokens) -> str:
        client = self._get_anthropic_client()
        response = client.messages.create(
            model=settings.ANTHROPIC_MODEL,
            max_tokens=max_tokens,
            system=system or "You are a helpful, precise assistant.",
            messages=messages,
        )
        return "".join(block.text for block in response.content if hasattr(block, "text"))

    def _chat_openai(self, messages, system, max_tokens) -> str:
        client = self._get_openai_client()
        full_messages = ([{"role": "system", "content": system}] if system else []) + messages
        response = client.chat.completions.create(
            model=settings.OPENAI_MODEL,
            max_tokens=max_tokens,
            messages=full_messages,
        )
        return response.choices[0].message.content

    def _echo_fallback(self, messages) -> str:
        """
        Used when LLM_PROVIDER=none or no API key is configured, so the
        rest of the pipeline (retrieval, graph, memory, evaluation) can
        still be exercised/tested without hitting a paid API.
        """
        last_user_msg = next((m["content"] for m in reversed(messages) if m["role"] == "user"), "")
        logger.warning("LLM_PROVIDER=none — returning a stub response instead of calling a real LLM.")
        return (
            "[No LLM configured — set ANTHROPIC_API_KEY or OPENAI_API_KEY in .env]\n"
            f"You asked: {last_user_msg[:300]}"
        )


_singleton: Optional[LLMClient] = None


def get_llm_client() -> LLMClient:
    global _singleton
    if _singleton is None:
        _singleton = LLMClient()
    return _singleton
