"""
Web scraping module.

Fetches raw HTML from a list of URLs and extracts readable text using
BeautifulSoup. Designed to be swappable with Scrapy for larger crawls;
this simple synchronous version is sufficient for building a static
knowledge base from a curated list of sources.
"""
import json
import logging
import time
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import List

import requests
from bs4 import BeautifulSoup

from src.config import settings, RAW_DATA_DIR

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@dataclass
class ScrapedDocument:
    url: str
    title: str
    text: str


class WebScraper:
    def __init__(self, timeout: int = None, user_agent: str = None, delay: float = 1.0):
        self.timeout = timeout or settings.SCRAPER_TIMEOUT
        self.headers = {"User-Agent": user_agent or settings.SCRAPER_USER_AGENT}
        self.delay = delay

    def fetch(self, url: str) -> str:
        response = requests.get(url, headers=self.headers, timeout=self.timeout)
        response.raise_for_status()
        return response.text

    def extract_text(self, html: str) -> str:
        soup = BeautifulSoup(html, "html.parser")
        for tag in soup(["script", "style", "nav", "footer", "header", "noscript", "form"]):
            tag.decompose()
        text = soup.get_text(separator="\n")
        lines = [line.strip() for line in text.splitlines()]
        lines = [line for line in lines if line]
        return "\n".join(lines)

    def extract_title(self, html: str) -> str:
        soup = BeautifulSoup(html, "html.parser")
        return soup.title.string.strip() if soup.title and soup.title.string else ""

    def scrape_url(self, url: str) -> ScrapedDocument:
        logger.info(f"Scraping {url}")
        html = self.fetch(url)
        return ScrapedDocument(
            url=url,
            title=self.extract_title(html),
            text=self.extract_text(html),
        )

    def scrape_urls(self, urls: List[str]) -> List[ScrapedDocument]:
        docs = []
        for url in urls:
            try:
                docs.append(self.scrape_url(url))
            except Exception as exc:
                logger.warning(f"Failed to scrape {url}: {exc}")
            time.sleep(self.delay)
        return docs

    @staticmethod
    def save_documents(docs: List[ScrapedDocument], out_path: Path = None) -> Path:
        out_path = out_path or (RAW_DATA_DIR / "scraped_documents.json")
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump([asdict(d) for d in docs], f, ensure_ascii=False, indent=2)
        logger.info(f"Saved {len(docs)} documents to {out_path}")
        return out_path


if __name__ == "__main__":
    sample_urls = [
        "https://en.wikipedia.org/wiki/Retrieval-augmented_generation",
        "https://en.wikipedia.org/wiki/Knowledge_graph",
    ]
    scraper = WebScraper()
    documents = scraper.scrape_urls(sample_urls)
    scraper.save_documents(documents)
