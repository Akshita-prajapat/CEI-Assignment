"""
Cleans and normalizes raw scraped text prior to chunking/embedding.
"""
import json
import re
from pathlib import Path
from typing import List, Dict

from src.config import RAW_DATA_DIR, PROCESSED_DATA_DIR

WHITESPACE_RE = re.compile(r"[ \t]+")
MULTI_NEWLINE_RE = re.compile(r"\n{3,}")
BOILERPLATE_PATTERNS = [
    r"cookie policy",
    r"all rights reserved",
    r"subscribe to our newsletter",
    r"privacy policy",
]


def clean_text(text: str) -> str:
    text = text.strip()
    text = WHITESPACE_RE.sub(" ", text)
    text = MULTI_NEWLINE_RE.sub("\n\n", text)
    lines = text.split("\n")
    cleaned_lines = []
    for line in lines:
        lower = line.lower()
        if any(re.search(p, lower) for p in BOILERPLATE_PATTERNS):
            continue
        if len(line.strip()) < 2:
            continue
        cleaned_lines.append(line.strip())
    return "\n".join(cleaned_lines)


def deduplicate_documents(docs: List[Dict]) -> List[Dict]:
    seen = set()
    unique = []
    for doc in docs:
        key = doc["text"][:200]
        if key not in seen:
            seen.add(key)
            unique.append(doc)
    return unique


def clean_documents(input_path: Path = None, output_path: Path = None) -> Path:
    input_path = input_path or (RAW_DATA_DIR / "scraped_documents.json")
    output_path = output_path or (PROCESSED_DATA_DIR / "cleaned_documents.json")

    with open(input_path, "r", encoding="utf-8") as f:
        docs = json.load(f)

    for doc in docs:
        doc["text"] = clean_text(doc["text"])

    docs = [d for d in docs if len(d["text"]) > 50]
    docs = deduplicate_documents(docs)

    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(docs, f, ensure_ascii=False, indent=2)

    return output_path


if __name__ == "__main__":
    out = clean_documents()
    print(f"Cleaned documents written to {out}")
