"""
Long-term memory store.

Persists per-user preferences and conversation history in SQLite so
memory survives across sessions/process restarts. This is the
"remembers who you are" layer that plain RAG lacks.
"""
import json
import logging
import sqlite3
import time
from contextlib import contextmanager
from pathlib import Path
from typing import List, Dict, Optional

from src.config import settings

logger = logging.getLogger(__name__)

SCHEMA = """
CREATE TABLE IF NOT EXISTS user_preferences (
    user_id TEXT NOT NULL,
    key TEXT NOT NULL,
    value TEXT NOT NULL,
    updated_at REAL NOT NULL,
    PRIMARY KEY (user_id, key)
);

CREATE TABLE IF NOT EXISTS conversation_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id TEXT NOT NULL,
    role TEXT NOT NULL,
    content TEXT NOT NULL,
    created_at REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS memory_facts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id TEXT NOT NULL,
    fact TEXT NOT NULL,
    created_at REAL NOT NULL
);
"""


class MemoryStore:
    def __init__(self, db_path: str = None):
        self.db_path = db_path or settings.MEMORY_DB_PATH
        Path(self.db_path).parent.mkdir(parents=True, exist_ok=True)
        self._init_db()

    @contextmanager
    def _connect(self):
        conn = sqlite3.connect(self.db_path)
        try:
            yield conn
            conn.commit()
        finally:
            conn.close()

    def _init_db(self):
        with self._connect() as conn:
            conn.executescript(SCHEMA)

    # ---------- Preferences ----------
    def set_preference(self, user_id: str, key: str, value: str):
        with self._connect() as conn:
            conn.execute(
                "INSERT INTO user_preferences (user_id, key, value, updated_at) VALUES (?, ?, ?, ?) "
                "ON CONFLICT(user_id, key) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at",
                (user_id, key, value, time.time()),
            )

    def get_preferences(self, user_id: str) -> Dict[str, str]:
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT key, value FROM user_preferences WHERE user_id = ?", (user_id,)
            ).fetchall()
        return {k: v for k, v in rows}

    # ---------- Conversation history ----------
    def add_message(self, user_id: str, role: str, content: str):
        with self._connect() as conn:
            conn.execute(
                "INSERT INTO conversation_history (user_id, role, content, created_at) VALUES (?, ?, ?, ?)",
                (user_id, role, content, time.time()),
            )

    def get_recent_history(self, user_id: str, limit: int = 10) -> List[Dict]:
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT role, content, created_at FROM conversation_history "
                "WHERE user_id = ? ORDER BY created_at DESC LIMIT ?",
                (user_id, limit),
            ).fetchall()
        rows.reverse()
        return [{"role": r, "content": c, "created_at": t} for r, c, t in rows]

    # ---------- Long-term "facts" extracted from conversation ----------
    def add_fact(self, user_id: str, fact: str):
        with self._connect() as conn:
            conn.execute(
                "INSERT INTO memory_facts (user_id, fact, created_at) VALUES (?, ?, ?)",
                (user_id, fact, time.time()),
            )
            # prune oldest facts beyond MAX_MEMORY_ITEMS
            count = conn.execute(
                "SELECT COUNT(*) FROM memory_facts WHERE user_id = ?", (user_id,)
            ).fetchone()[0]
            if count > settings.MAX_MEMORY_ITEMS:
                excess = count - settings.MAX_MEMORY_ITEMS
                ids_to_delete = conn.execute(
                    "SELECT id FROM memory_facts WHERE user_id = ? ORDER BY created_at ASC LIMIT ?",
                    (user_id, excess),
                ).fetchall()
                conn.executemany("DELETE FROM memory_facts WHERE id = ?", ids_to_delete)

    def get_facts(self, user_id: str) -> List[str]:
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT fact FROM memory_facts WHERE user_id = ? ORDER BY created_at ASC", (user_id,)
            ).fetchall()
        return [r[0] for r in rows]

    def format_memory_context(self, user_id: str) -> str:
        prefs = self.get_preferences(user_id)
        facts = self.get_facts(user_id)
        parts = []
        if prefs:
            pref_lines = "\n".join(f"- {k}: {v}" for k, v in prefs.items())
            parts.append(f"User preferences:\n{pref_lines}")
        if facts:
            fact_lines = "\n".join(f"- {f}" for f in facts)
            parts.append(f"Known facts about the user:\n{fact_lines}")
        return "\n\n".join(parts)


_singleton: Optional[MemoryStore] = None


def get_memory_store() -> MemoryStore:
    global _singleton
    if _singleton is None:
        _singleton = MemoryStore()
    return _singleton
