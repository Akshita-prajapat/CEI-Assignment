"""
Decides what from a conversation turn is worth remembering long-term,
and writes it into the MemoryStore. Uses simple heuristics by default;
if an LLM client is available it can optionally be used for smarter
extraction (see extract_facts_with_llm).
"""
import logging
import re
from typing import Optional

from src.memory.memory_store import get_memory_store

logger = logging.getLogger(__name__)

PREFERENCE_PATTERNS = [
    (re.compile(r"\bmy name is ([A-Za-z]+)\b", re.I), "name"),
    (re.compile(r"\bi live in ([A-Za-z]+(?:\s[A-Za-z]+)*?)(?=[,\.\!\?]|$|\sand\b)", re.I), "location"),
    (re.compile(r"\bi work as (?:an?\s)?([A-Za-z]+(?:\s[A-Za-z]+)*?)(?=[,\.\!\?]|$|\sand\b)", re.I), "occupation"),
    (re.compile(r"\bi (?:like|love|prefer) ([A-Za-z0-9]+(?:\s[A-Za-z0-9]+)*?)(?=[,\.\!\?]|$|\sand\b)", re.I), "likes"),
    (re.compile(r"\bi (?:dislike|hate|don't like) ([A-Za-z0-9]+(?:\s[A-Za-z0-9]+)*?)(?=[,\.\!\?]|$|\sand\b)", re.I), "dislikes"),
]


class UserMemoryManager:
    def __init__(self):
        self.store = get_memory_store()

    def process_turn(self, user_id: str, user_message: str, assistant_message: str = ""):
        """Call after each user turn to update long-term memory heuristically."""
        self.store.add_message(user_id, "user", user_message)
        if assistant_message:
            self.store.add_message(user_id, "assistant", assistant_message)

        for pattern, key in PREFERENCE_PATTERNS:
            match = pattern.search(user_message)
            if match:
                value = match.group(match.lastindex).strip()
                if key in ("name", "location"):
                    self.store.set_preference(user_id, key, value)
                else:
                    self.store.add_fact(user_id, f"{key}: {value}")

    def extract_facts_with_llm(self, user_id: str, user_message: str, llm_client=None):
        """
        Optional smarter extraction path using an LLM to pull out durable
        facts/preferences from free-form text. Falls back silently if no
        llm_client is provided.
        """
        if llm_client is None:
            return
        prompt = (
            "Extract any durable personal facts or preferences from this message "
            "that would be useful to remember about the user in future conversations. "
            "Return them as a short bullet list, or 'NONE' if there is nothing worth remembering.\n\n"
            f"Message: {user_message}"
        )
        try:
            response = llm_client.complete(prompt)
            if response and "NONE" not in response.upper():
                for line in response.splitlines():
                    line = line.strip("-• ").strip()
                    if line:
                        self.store.add_fact(user_id, line)
        except Exception as exc:
            logger.warning(f"LLM-based fact extraction failed: {exc}")

    def get_context(self, user_id: str) -> str:
        return self.store.format_memory_context(user_id)
