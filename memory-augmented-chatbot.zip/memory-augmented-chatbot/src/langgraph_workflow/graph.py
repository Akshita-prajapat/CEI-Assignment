"""
Wires together the LangGraph workflow:

                 ┌─────────────┐
   query ───────▶│ memory_node │  (always fetch user's long-term memory first)
                 └──────┬──────┘
                        ▼
                 ┌─────────────┐
                 │ router_node │  (decides: real-time tool vs static RAG+graph)
                 └──────┬──────┘
              ┌─────────┴─────────┐
              ▼                   ▼
        ┌──────────┐        ┌──────────┐
        │ tool_node│        │ rag_node │
        └────┬─────┘        └────┬─────┘
             │                   ▼
             │             ┌──────────┐
             │             │graph_node│
             │             └────┬─────┘
             └─────────┬────────┘
                        ▼
                 generation_node
                        │
                        ▼
                     END (final_answer)
"""
import logging

from langgraph.graph import StateGraph, END

from src.langgraph_workflow.state import ChatState
from src.langgraph_workflow.nodes import (
    router_node,
    memory_node,
    rag_node,
    graph_node,
    tool_node,
    generation_node,
)

logger = logging.getLogger(__name__)


def _route_decision(state: ChatState) -> str:
    return state.get("route", "rag_and_graph")


def build_chat_graph():
    workflow = StateGraph(ChatState)

    workflow.add_node("router", router_node)
    workflow.add_node("memory", memory_node)
    workflow.add_node("rag", rag_node)
    workflow.add_node("graph", graph_node)
    workflow.add_node("tool", tool_node)
    workflow.add_node("generate", generation_node)

    # Memory is always fetched first (personalization applies regardless
    # of which retrieval path is taken), then the router decides the rest.
    workflow.set_entry_point("memory")
    workflow.add_edge("memory", "router")

    # Router decides: either go fetch real-time tool info, or do
    # static RAG + knowledge-graph retrieval.
    workflow.add_conditional_edges(
        "router",
        _route_decision,
        {
            "tool": "tool",
            "rag_and_graph": "rag",
        },
    )

    # rag_and_graph branch: rag -> graph -> generate
    workflow.add_edge("rag", "graph")
    workflow.add_edge("graph", "generate")

    # tool branch: tool -> generate
    workflow.add_edge("tool", "generate")

    workflow.add_edge("generate", END)

    return workflow.compile()


_compiled_graph = None


def get_chat_graph():
    global _compiled_graph
    if _compiled_graph is None:
        _compiled_graph = build_chat_graph()
    return _compiled_graph


def run_chat(user_id: str, query: str) -> dict:
    graph = get_chat_graph()
    result = graph.invoke({"user_id": user_id, "query": query})
    return result
