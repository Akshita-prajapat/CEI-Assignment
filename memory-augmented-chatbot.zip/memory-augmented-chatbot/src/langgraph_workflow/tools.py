"""
Dynamic tools the LangGraph tool_node can call to fetch real-time
information that neither the static RAG index nor the knowledge graph
would contain (e.g. current weather, live web search, quick math).

Each tool is a plain Python function with a docstring description and
a JSON-schema-like signature, registered in TOOL_REGISTRY so the
router/tool node can pick one by name.
"""
import logging
import re
from typing import Dict

import requests

logger = logging.getLogger(__name__)


def get_current_weather(location: str) -> str:
    """Fetch current weather for a location using the free Open-Meteo API (no key required)."""
    try:
        geo = requests.get(
            "https://geocoding-api.open-meteo.com/v1/search",
            params={"name": location, "count": 1},
            timeout=10,
        ).json()
        if not geo.get("results"):
            return f"Could not find location: {location}"
        lat, lon = geo["results"][0]["latitude"], geo["results"][0]["longitude"]

        weather = requests.get(
            "https://api.open-meteo.com/v1/forecast",
            params={"latitude": lat, "longitude": lon, "current_weather": True},
            timeout=10,
        ).json()
        current = weather.get("current_weather", {})
        return (
            f"Current weather in {location}: {current.get('temperature')}°C, "
            f"windspeed {current.get('windspeed')} km/h."
        )
    except Exception as exc:
        logger.warning(f"Weather tool failed: {exc}")
        return f"Sorry, I couldn't fetch live weather for {location} right now."


def calculator(expression: str) -> str:
    """Safely evaluate a basic arithmetic expression."""
    if not re.fullmatch(r"[0-9\.\+\-\*\/\(\)\s]+", expression):
        return "Invalid expression: only basic arithmetic is supported."
    try:
        result = eval(expression, {"__builtins__": {}})
        return f"{expression} = {result}"
    except Exception as exc:
        return f"Could not evaluate expression: {exc}"


def web_search_stub(query: str) -> str:
    """
    Placeholder for a real-time web search tool. Plug in a real search
    API (e.g. Tavily, SerpAPI, Bing) here by replacing the body of this
    function — the rest of the LangGraph workflow does not need to change.
    """
    return (
        f"[web_search_stub] Real-time web search is not configured. "
        f"Wire up a search API for the query: '{query}'."
    )


TOOL_REGISTRY: Dict[str, callable] = {
    "get_current_weather": get_current_weather,
    "calculator": calculator,
    "web_search": web_search_stub,
}

TOOL_DESCRIPTIONS = {
    "get_current_weather": "Get current weather for a named location.",
    "calculator": "Evaluate a basic arithmetic expression.",
    "web_search": "Search the live web for up-to-date information.",
}


def route_to_tool(query: str) -> str:
    """Very small heuristic router deciding which tool (if any) fits the query."""
    lowered = query.lower()
    if "weather" in lowered:
        return "get_current_weather"
    if re.search(r"\d\s*[\+\-\*/]\s*\d", query):
        return "calculator"
    if any(kw in lowered for kw in ("latest", "today", "current", "news", "right now")):
        return "web_search"
    return ""


def run_tool(query: str) -> str:
    tool_name = route_to_tool(query)
    if not tool_name:
        return ""
    tool_fn = TOOL_REGISTRY[tool_name]
    if tool_name == "get_current_weather":
        match = re.search(r"weather.*?in\s+([A-Za-z\s]+)", query, re.I)
        location = match.group(1).strip() if match else query
        return tool_fn(location)
    if tool_name == "calculator":
        # Match a contiguous run of arithmetic characters that contains at
        # least one digit (avoids matching leading whitespace/words).
        match = re.search(r"[0-9][0-9\.\+\-\*\/\(\)\s]*[0-9\)]|[0-9]", query)
        expr = match.group(0).strip() if match else query
        return tool_fn(expr)
    return tool_fn(query)
