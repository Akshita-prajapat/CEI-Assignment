"""
LangGraph node functions. Each node takes the shared ChatState, does
one job, and returns the fields it updated.
"""
import logging
from typing import Dict

from src.langgraph_workflow.state import ChatState
from src.langgraph_workflow.tools import run_tool, route_to_tool
from src.rag.retriever import Retriever
from src.knowledge_graph.graph_query import GraphQueryEngine
from src.memory.user_memory import UserMemoryManager
from src.llm.llm_client import get_llm_client

logger = logging.getLogger(__name__)

_retriever = None
_graph_engine = None
_memory_manager = None


def _get_retriever() -> Retriever:
    global _retriever
    if _retriever is None:
        _retriever = Retriever()
    return _retriever


def _get_graph_engine() -> GraphQueryEngine:
    global _graph_engine
    if _graph_engine is None:
        _graph_engine = GraphQueryEngine()
    return _graph_engine


def _get_memory_manager() -> UserMemoryManager:
    global _memory_manager
    if _memory_manager is None:
        _memory_manager = UserMemoryManager()
    return _memory_manager


def router_node(state: ChatState) -> Dict:
    """
    Decides whether the query needs a real-time tool, is a
    relational/graph-style question, or is best served by static RAG.
    Multiple routes can fire — this just decides tool usage explicitly;
    RAG and graph retrieval both run by default for context breadth.
    """
    query = state["query"]
    tool_name = route_to_tool(query)
    route = "tool" if tool_name else "rag_and_graph"
    logger.info(f"Router decided: {route}")
    return {"route": route}


def memory_node(state: ChatState) -> Dict:
    memory_manager = _get_memory_manager()
    context = memory_manager.get_context(state["user_id"])
    return {"memory_context": context}


def rag_node(state: ChatState) -> Dict:
    retriever = _get_retriever()
    context, sources = retriever.retrieve_with_context(state["query"])
    return {"rag_context": context, "rag_sources": sources}


def graph_node(state: ChatState) -> Dict:
    engine = _get_graph_engine()
    results = engine.query(state["query"])
    context = engine.format_as_context(results)
    return {"graph_context": context}


def tool_node(state: ChatState) -> Dict:
    result = run_tool(state["query"])
    return {"tool_context": result}


def generation_node(state: ChatState) -> Dict:
    llm = get_llm_client()

    context_parts = []
    if state.get("memory_context"):
        context_parts.append(f"--- User memory ---\n{state['memory_context']}")
    if state.get("rag_context"):
        context_parts.append(f"--- Retrieved knowledge (RAG) ---\n{state['rag_context']}")
    if state.get("graph_context"):
        context_parts.append(f"--- Knowledge graph facts ---\n{state['graph_context']}")
    if state.get("tool_context"):
        context_parts.append(f"--- Real-time tool result ---\n{state['tool_context']}")

    context_block = "\n\n".join(context_parts) if context_parts else "No additional context retrieved."

    system_prompt = (
        "You are a helpful, personalized assistant with access to retrieved knowledge, "
        "a knowledge graph, real-time tools, and long-term memory about the user. "
        "Use the provided context to answer accurately. If the context doesn't contain "
        "the answer, say so honestly rather than making things up. Personalize your "
        "response using the user memory when relevant."
    )

    prompt = f"{context_block}\n\n--- User question ---\n{state['query']}"

    answer = llm.complete(prompt, system=system_prompt, max_tokens=1024)

    memory_manager = _get_memory_manager()
    memory_manager.process_turn(state["user_id"], state["query"], answer)

    return {"final_answer": answer}
