"""
Shared state object passed between LangGraph nodes.
"""
from typing import List, Dict, Optional, TypedDict


class ChatState(TypedDict, total=False):
    user_id: str
    query: str
    route: str                      # decided by the router node: "rag" | "graph" | "tool" | "direct"
    memory_context: str
    rag_context: str
    rag_sources: List[Dict]
    graph_context: str
    tool_context: str
    final_answer: str
    history: List[Dict]
