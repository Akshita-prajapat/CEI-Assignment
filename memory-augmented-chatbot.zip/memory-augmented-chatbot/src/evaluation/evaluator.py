"""
Runs the chatbot pipeline against a labelled evaluation dataset and
produces an aggregate quality report (JSON + printed summary).

Dataset format (see data/sample_eval_dataset.json):
[
  {
    "query": "What is retrieval-augmented generation?",
    "reference_answer": "...",
    "expected_keywords": ["retrieval", "generation", "LLM"]
  },
  ...
]
"""
import json
import logging
import statistics
import time
from pathlib import Path
from typing import List, Dict

from src.evaluation import metrics
from src.langgraph_workflow.graph import run_chat
from src.llm.llm_client import get_llm_client
from src.config import settings, BASE_DIR

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class Evaluator:
    def __init__(self, use_llm_judge: bool = True):
        self.use_llm_judge = use_llm_judge and settings.LLM_PROVIDER != "none"
        self.llm_client = get_llm_client() if self.use_llm_judge else None

    def evaluate_single(self, user_id: str, item: Dict) -> Dict:
        query = item["query"]
        reference_answer = item.get("reference_answer", "")
        expected_keywords = item.get("expected_keywords", [])

        start = time.time()
        result = run_chat(user_id, query)
        latency = round(time.time() - start, 3)

        answer = result.get("final_answer", "")
        context = "\n".join(
            filter(None, [result.get("rag_context", ""), result.get("graph_context", "")])
        )

        scores = {
            "context_relevance": metrics.context_relevance(query, context),
            "answer_similarity": metrics.answer_similarity(answer, reference_answer),
            "keyword_coverage": metrics.keyword_coverage(answer, expected_keywords),
            "response_length_ratio": metrics.response_length_ratio(answer),
            "latency_seconds": latency,
        }

        if self.use_llm_judge:
            faithfulness = metrics.llm_judge_faithfulness(query, context, answer, self.llm_client)
            correctness = metrics.llm_judge_correctness(query, answer, reference_answer, self.llm_client)
            if faithfulness is not None:
                scores["faithfulness"] = faithfulness
            if correctness is not None:
                scores["correctness"] = correctness

        return {
            "query": query,
            "answer": answer,
            "scores": scores,
        }

    def evaluate_dataset(self, dataset_path: Path, user_id: str = "eval_user") -> Dict:
        with open(dataset_path, "r", encoding="utf-8") as f:
            dataset = json.load(f)

        results = [self.evaluate_single(user_id, item) for item in dataset]

        aggregate = {}
        metric_names = set()
        for r in results:
            metric_names.update(r["scores"].keys())
        for name in metric_names:
            values = [r["scores"][name] for r in results if name in r["scores"]]
            if values:
                aggregate[name] = {
                    "mean": round(statistics.mean(values), 4),
                    "min": round(min(values), 4),
                    "max": round(max(values), 4),
                }

        report = {"num_examples": len(results), "aggregate": aggregate, "results": results}
        return report

    @staticmethod
    def save_report(report: Dict, out_path: Path = None) -> Path:
        out_path = out_path or (BASE_DIR / "data" / "evaluation_report.json")
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(report, f, ensure_ascii=False, indent=2)
        return out_path


def print_summary(report: Dict):
    print(f"\nEvaluated {report['num_examples']} examples\n" + "-" * 40)
    for metric_name, stats in report["aggregate"].items():
        print(f"{metric_name:24s} mean={stats['mean']:<8} min={stats['min']:<8} max={stats['max']}")
    print("-" * 40)


if __name__ == "__main__":
    dataset_path = BASE_DIR / "data" / "sample_eval_dataset.json"
    evaluator = Evaluator()
    report = evaluator.evaluate_dataset(dataset_path)
    out_path = evaluator.save_report(report)
    print_summary(report)
    print(f"\nFull report saved to {out_path}")
