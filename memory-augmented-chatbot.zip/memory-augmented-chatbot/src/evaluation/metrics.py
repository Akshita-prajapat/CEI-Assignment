"""
Evaluation metrics for the chatbot pipeline.

Two families of metrics are provided:
  1. Embedding-similarity based (fast, deterministic, no LLM call):
     - context_relevance: does retrieved context relate to the query?
     - answer_similarity: does the answer semantically match a reference?
  2. LLM-judge based (optional, requires an LLM client):
     - faithfulness: is the answer grounded in the retrieved context?
     - correctness: does the answer match the reference answer?

Both families are combined by the Evaluator so users without an LLM
API key configured can still get useful signal from metric family 1.
"""
import logging
import re
from typing import List, Dict, Optional

import numpy as np

from src.rag.embeddings import get_embedding_model

logger = logging.getLogger(__name__)


def _cosine_similarity(a: np.ndarray, b: np.ndarray) -> float:
    a, b = a.flatten(), b.flatten()
    denom = (np.linalg.norm(a) * np.linalg.norm(b))
    if denom == 0:
        return 0.0
    return float(np.dot(a, b) / denom)


def context_relevance(query: str, context: str) -> float:
    """Cosine similarity between the query and retrieved context (0-1)."""
    if not context:
        return 0.0
    embedder = get_embedding_model()
    q_vec = embedder.embed([query])
    c_vec = embedder.embed([context])
    return round(max(0.0, _cosine_similarity(q_vec, c_vec)), 4)


def answer_similarity(answer: str, reference_answer: str) -> float:
    """Cosine similarity between generated answer and a reference/gold answer (0-1)."""
    if not reference_answer or not answer:
        return 0.0
    embedder = get_embedding_model()
    a_vec = embedder.embed([answer])
    r_vec = embedder.embed([reference_answer])
    return round(max(0.0, _cosine_similarity(a_vec, r_vec)), 4)


def keyword_coverage(answer: str, expected_keywords: List[str]) -> float:
    """Fraction of expected keywords present in the answer (0-1)."""
    if not expected_keywords:
        return 1.0
    lowered = answer.lower()
    hits = sum(1 for kw in expected_keywords if kw.lower() in lowered)
    return round(hits / len(expected_keywords), 4)


def response_length_ratio(answer: str, min_words: int = 5, max_words: int = 400) -> float:
    """Penalizes answers that are too short (likely unhelpful) or excessively long."""
    n = len(answer.split())
    if n < min_words:
        return round(n / min_words, 4)
    if n > max_words:
        return round(max_words / n, 4)
    return 1.0


def llm_judge_faithfulness(query: str, context: str, answer: str, llm_client) -> Optional[float]:
    """
    Uses an LLM to judge whether the answer is grounded in the given
    context (i.e. not hallucinated). Returns a 0-1 score, or None if
    no llm_client is available.
    """
    if llm_client is None or not context:
        return None
    prompt = (
        "You are grading whether an AI answer is faithful to (i.e. supported by) "
        "the given context. Respond with ONLY a number from 0 to 1 "
        "(1 = fully supported, 0 = not supported / hallucinated).\n\n"
        f"Context:\n{context}\n\nQuestion:\n{query}\n\nAnswer:\n{answer}\n\nScore:"
    )
    try:
        response = llm_client.complete(prompt, max_tokens=10)
        match = re.search(r"[01](?:\.\d+)?", response)
        return float(match.group()) if match else None
    except Exception as exc:
        logger.warning(f"LLM faithfulness judge failed: {exc}")
        return None


def llm_judge_correctness(query: str, answer: str, reference_answer: str, llm_client) -> Optional[float]:
    """Uses an LLM to judge answer correctness against a reference answer, 0-1."""
    if llm_client is None or not reference_answer:
        return None
    prompt = (
        "You are grading whether an AI's answer correctly answers the question, "
        "compared to a reference answer. Respond with ONLY a number from 0 to 1.\n\n"
        f"Question:\n{query}\n\nReference answer:\n{reference_answer}\n\n"
        f"AI answer:\n{answer}\n\nScore:"
    )
    try:
        response = llm_client.complete(prompt, max_tokens=10)
        match = re.search(r"[01](?:\.\d+)?", response)
        return float(match.group()) if match else None
    except Exception as exc:
        logger.warning(f"LLM correctness judge failed: {exc}")
        return None
