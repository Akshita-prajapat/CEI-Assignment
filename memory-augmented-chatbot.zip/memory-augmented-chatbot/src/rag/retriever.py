"""
Retriever: thin orchestration layer over the vector store that formats
retrieved chunks into a context string for the LLM, and exposes the
raw sources for citation and evaluation purposes.
"""
from typing import List, Dict, Tuple

from src.config import settings
from src.rag.vector_store import get_vector_store


class Retriever:
    def __init__(self, top_k: int = None):
        self.top_k = top_k or settings.TOP_K
        self.vector_store = get_vector_store()

    def retrieve(self, query: str) -> List[Dict]:
        return self.vector_store.search(query, top_k=self.top_k)

    def retrieve_with_context(self, query: str) -> Tuple[str, List[Dict]]:
        results = self.retrieve(query)
        if not results:
            return "", []

        context_blocks = []
        for i, r in enumerate(results):
            source = r.get("doc_title") or r.get("doc_url") or "unknown source"
            context_blocks.append(f"[{i+1}] Source: {source}\n{r['text']}")
        context = "\n\n".join(context_blocks)
        return context, results
