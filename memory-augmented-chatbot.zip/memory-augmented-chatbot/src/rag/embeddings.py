"""
Embedding generation using sentence-transformers.

Wrapped in a small class so the rest of the codebase doesn't care
which embedding backend is used. Swap `EMBEDDING_MODEL` in config.py
to change models (any sentence-transformers-compatible model works).
"""
import logging
from functools import lru_cache
from typing import List

import numpy as np

from src.config import settings

logger = logging.getLogger(__name__)


class EmbeddingModel:
    def __init__(self, model_name: str = None):
        self.model_name = model_name or settings.EMBEDDING_MODEL
        self._model = None

    @property
    def model(self):
        if self._model is None:
            from sentence_transformers import SentenceTransformer
            logger.info(f"Loading embedding model: {self.model_name}")
            self._model = SentenceTransformer(self.model_name)
        return self._model

    def embed(self, texts: List[str]) -> np.ndarray:
        if isinstance(texts, str):
            texts = [texts]
        embeddings = self.model.encode(texts, convert_to_numpy=True, show_progress_bar=False)
        return embeddings.astype("float32")

    @property
    def dimension(self) -> int:
        return self.model.get_sentence_embedding_dimension()


@lru_cache(maxsize=1)
def get_embedding_model() -> EmbeddingModel:
    """Cached singleton so the model is loaded only once per process."""
    return EmbeddingModel()
