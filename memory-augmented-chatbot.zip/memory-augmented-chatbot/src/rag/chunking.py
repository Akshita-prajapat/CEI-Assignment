"""
Splits cleaned documents into overlapping chunks suitable for embedding.
"""
import json
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import List, Dict

from src.config import settings, PROCESSED_DATA_DIR


@dataclass
class Chunk:
    chunk_id: str
    doc_url: str
    doc_title: str
    text: str


def chunk_text(text: str, chunk_size: int = None, overlap: int = None) -> List[str]:
    chunk_size = chunk_size or settings.CHUNK_SIZE
    overlap = overlap or settings.CHUNK_OVERLAP
    words = text.split()
    if not words:
        return []

    chunks = []
    start = 0
    while start < len(words):
        end = min(start + chunk_size, len(words))
        chunks.append(" ".join(words[start:end]))
        if end == len(words):
            break
        start = end - overlap
    return chunks


def chunk_documents(input_path: Path = None, output_path: Path = None) -> Path:
    input_path = input_path or (PROCESSED_DATA_DIR / "cleaned_documents.json")
    output_path = output_path or (PROCESSED_DATA_DIR / "chunks.json")

    with open(input_path, "r", encoding="utf-8") as f:
        docs: List[Dict] = json.load(f)

    all_chunks: List[Chunk] = []
    for doc_idx, doc in enumerate(docs):
        pieces = chunk_text(doc["text"])
        for piece_idx, piece in enumerate(pieces):
            all_chunks.append(
                Chunk(
                    chunk_id=f"doc{doc_idx}_chunk{piece_idx}",
                    doc_url=doc.get("url", ""),
                    doc_title=doc.get("title", ""),
                    text=piece,
                )
            )

    with open(output_path, "w", encoding="utf-8") as f:
        json.dump([asdict(c) for c in all_chunks], f, ensure_ascii=False, indent=2)

    return output_path


if __name__ == "__main__":
    out = chunk_documents()
    print(f"Chunks written to {out}")
