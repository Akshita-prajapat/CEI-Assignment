"""
FAISS-backed vector store for the static knowledge layer.

Stores chunk embeddings + metadata (text, source url, title) and
supports similarity search. Persisted to disk so the index only
needs to be built once (see scripts/build_knowledge_base.py).
"""
import json
import logging
import pickle
from pathlib import Path
from typing import List, Dict, Optional

import faiss
import numpy as np

from src.config import settings
from src.rag.embeddings import get_embedding_model

logger = logging.getLogger(__name__)


class VectorStore:
    def __init__(self, index_path: str = None, meta_path: str = None):
        self.index_path = index_path or settings.VECTOR_STORE_PATH
        self.meta_path = meta_path or settings.VECTOR_STORE_META_PATH
        self.index: Optional[faiss.Index] = None
        self.metadata: List[Dict] = []

    def build(self, chunks: List[Dict]):
        """chunks: list of dicts with at least a 'text' key."""
        embedder = get_embedding_model()
        texts = [c["text"] for c in chunks]
        embeddings = embedder.embed(texts)
        dim = embeddings.shape[1]

        index = faiss.IndexFlatIP(dim)
        faiss.normalize_L2(embeddings)
        index.add(embeddings)

        self.index = index
        self.metadata = chunks
        logger.info(f"Built FAISS index with {index.ntotal} vectors (dim={dim})")

    def save(self):
        Path(self.index_path).parent.mkdir(parents=True, exist_ok=True)
        faiss.write_index(self.index, str(self.index_path))
        with open(self.meta_path, "wb") as f:
            pickle.dump(self.metadata, f)
        logger.info(f"Saved index -> {self.index_path}, metadata -> {self.meta_path}")

    def load(self):
        self.index = faiss.read_index(str(self.index_path))
        with open(self.meta_path, "rb") as f:
            self.metadata = pickle.load(f)
        logger.info(f"Loaded index with {self.index.ntotal} vectors")

    def is_available(self) -> bool:
        return Path(self.index_path).exists() and Path(self.meta_path).exists()

    def search(self, query: str, top_k: int = None) -> List[Dict]:
        if self.index is None:
            if self.is_available():
                self.load()
            else:
                logger.warning("Vector store empty: no index built yet.")
                return []

        top_k = top_k or settings.TOP_K
        embedder = get_embedding_model()
        query_vec = embedder.embed([query])
        faiss.normalize_L2(query_vec)

        scores, indices = self.index.search(query_vec, top_k)
        results = []
        for score, idx in zip(scores[0], indices[0]):
            if idx == -1:
                continue
            item = dict(self.metadata[idx])
            item["score"] = float(score)
            results.append(item)
        return results


_singleton: Optional[VectorStore] = None


def get_vector_store() -> VectorStore:
    global _singleton
    if _singleton is None:
        _singleton = VectorStore()
    return _singleton
