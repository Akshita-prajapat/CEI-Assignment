"""
Central configuration for the Memory-Augmented Chatbot.

All settings are read from environment variables (see .env.example),
with sensible local-friendly defaults so the project runs out of the
box using file-based storage (FAISS + SQLite + NetworkX) without
requiring any external services like Neo4j, Postgres, or Mongo.
"""
import os
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
RAW_DATA_DIR = DATA_DIR / "raw"
PROCESSED_DATA_DIR = DATA_DIR / "processed"
INDEX_DIR = DATA_DIR / "index"

for d in (RAW_DATA_DIR, PROCESSED_DATA_DIR, INDEX_DIR):
    d.mkdir(parents=True, exist_ok=True)


class Settings:
    # --- LLM provider ---
    LLM_PROVIDER: str = os.getenv("LLM_PROVIDER", "anthropic")  # "anthropic" | "openai" | "none"
    ANTHROPIC_API_KEY: str = os.getenv("ANTHROPIC_API_KEY", "")
    OPENAI_API_KEY: str = os.getenv("OPENAI_API_KEY", "")
    ANTHROPIC_MODEL: str = os.getenv("ANTHROPIC_MODEL", "claude-sonnet-4-6")
    OPENAI_MODEL: str = os.getenv("OPENAI_MODEL", "gpt-4o-mini")

    # --- Embeddings / vector store ---
    EMBEDDING_MODEL: str = os.getenv("EMBEDDING_MODEL", "sentence-transformers/all-MiniLM-L6-v2")
    VECTOR_STORE_PATH: str = os.getenv("VECTOR_STORE_PATH", str(INDEX_DIR / "faiss.index"))
    VECTOR_STORE_META_PATH: str = os.getenv("VECTOR_STORE_META_PATH", str(INDEX_DIR / "faiss_meta.pkl"))
    CHUNK_SIZE: int = int(os.getenv("CHUNK_SIZE", 500))
    CHUNK_OVERLAP: int = int(os.getenv("CHUNK_OVERLAP", 50))
    TOP_K: int = int(os.getenv("TOP_K", 4))

    # --- Knowledge graph ---
    GRAPH_BACKEND: str = os.getenv("GRAPH_BACKEND", "networkx")  # "networkx" | "neo4j"
    NEO4J_URI: str = os.getenv("NEO4J_URI", "bolt://localhost:7687")
    NEO4J_USER: str = os.getenv("NEO4J_USER", "neo4j")
    NEO4J_PASSWORD: str = os.getenv("NEO4J_PASSWORD", "password")
    GRAPH_STORE_PATH: str = os.getenv("GRAPH_STORE_PATH", str(INDEX_DIR / "knowledge_graph.gpickle"))

    # --- Long-term memory ---
    MEMORY_DB_PATH: str = os.getenv("MEMORY_DB_PATH", str(INDEX_DIR / "memory.sqlite3"))
    MAX_MEMORY_ITEMS: int = int(os.getenv("MAX_MEMORY_ITEMS", 50))

    # --- API ---
    API_HOST: str = os.getenv("API_HOST", "0.0.0.0")
    API_PORT: int = int(os.getenv("API_PORT", 8000))

    # --- Scraping ---
    SCRAPER_USER_AGENT: str = os.getenv(
        "SCRAPER_USER_AGENT",
        "Mozilla/5.0 (compatible; MemoryAugmentedChatbot/1.0; +https://github.com/)",
    )
    SCRAPER_TIMEOUT: int = int(os.getenv("SCRAPER_TIMEOUT", 10))


settings = Settings()
